// Tab
// Based On: Tab -> ContainerElement -> ViewElement
(function (Tab, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    Tab.Render = function (tab) {

        // Div<, TabIndex@, Class@, Id@, Div>
        var tabMarkup = '<div role="tabpanel" data-namespace="Tab" class="gtc-tab"' + ViewElement.RenderAttributes(tab) + '>';

        // Render Container ViewElements
        tabMarkup += ContainerElement.RenderElements(tab);

        // Div</>
        tabMarkup += '</div>';
        return tabMarkup;

    };

} (window.Tab = window.Tab || {}, window, document, Common, Cache, Events, Velocity));

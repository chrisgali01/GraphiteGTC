// Tab Footer
// Based On: TabFooter -> ViewElement
(function (TabFooter, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    TabFooter.Render = function (tabFooter) {

        // Ul<, TabIndex@, Class@, Id@, Ul>
        var tabIndex = tabFooter.FocusIndex;
        tabFooter.FocusIndex = null;
        var tabFooterMarkup = '<ul data-namespace="TabFooter" class="gtc-uitab"' + ViewElement.RenderAttributes(tabFooter) + '>';

        // Close
        if (Common.IsNotDefined(tabFooter.CloseTitle)) {
            tabFooter.CloseTitle = 'TabFooterCloseButton';
        }
        tabFooterMarkup += '<li><a alt="' + Common.TranslateKey(tabFooter.CloseTitle) + '" class="gtc-btn gtc-btn-button gtc-btn--basic gtc-btn--basic-passive gtc-btn--size-default"';
        if (Common.IsDefined(tabIndex)) {
            tabFooterMarkup += ' tabindex="' + tabIndex + '"';
        }
        tabFooterMarkup += ' id="TabFooterCloseButton" data-translate="' + tabFooter.CloseTitle + ';[alt]' + tabFooter.CloseTitle + ';">' + Common.TranslateKey(tabFooter.CloseTitle) + '</a></li>';

        // Next
        if (Common.IsNotDefined(tabFooter.NextTitle)) {
            tabFooter.NextTitle = 'TabFooterNextButton';
        }
        tabFooterMarkup += '<li><a alt="' + Common.TranslateKey(tabFooter.NextTitle) + '" class="gtc-btn gtc-btn-button gtc-btn--basic gtc-btn--basic-active gtc-btn--size-default"';
        if (Common.IsDefined(tabIndex)) {
            tabFooterMarkup += ' tabindex="' + tabIndex + '"';
        }
        tabFooterMarkup += ' data-nexttitle="' + tabFooter.NextTitle + '" id="TabFooterNextButton" data-translate="' + tabFooter.NextTitle + ';[alt]' + tabFooter.NextTitle + ';">' + Common.TranslateKey(tabFooter.NextTitle) + '</a></li>';

        // Footer Buttons
        if (Common.IsDefined(tabFooter.Buttons)) {
            var index = 0, length = tabFooter.Buttons.length;
            for ( ; index < length; index++) {
                tabFooterMarkup += '<li>' + Link.Render(tabFooter.Buttons[index]) + '</li>';
            }
        }

        // Previous
        if (Common.IsNotDefined(tabFooter.PreviousTitle)) {
            tabFooter.PreviousTitle = 'TabFooterPreviousButton';
        }
        tabFooterMarkup += '<li><a alt="' + Common.TranslateKey(tabFooter.PreviousTitle) + '" class="gtc-btn gtc-btn-button gtc-btn--basic gtc-btn--basic-active gtc-btn--size-default"';
        if (Common.IsDefined(tabIndex)) {
            tabFooterMarkup += ' tabindex="' + tabIndex + '"';
        }
        tabFooterMarkup += ' id="TabFooterPreviousButton" data-translate="' + tabFooter.PreviousTitle + ';[alt]' + tabFooter.PreviousTitle + ';">' + Common.TranslateKey(tabFooter.PreviousTitle) + '</a></li>';

        // Attach keys
        if (Common.IsDefined(tabFooter.PreviousAttachedKey)) {
            GTC.AttachKey('TabFooterPreviousButton', tabFooter.PreviousAttachedKey);
        }
        if (Common.IsDefined(tabFooter.NextAttachedKey)) {
            GTC.AttachKey('TabFooterNextButton', tabFooter.NextAttachedKey);
        }

        // Ul</>
        tabFooterMarkup += '</ul>';
        return tabFooterMarkup;

    };

} (window.TabFooter = window.TabFooter || {}, window, document, Common, Cache, Events, Velocity));

// Radio Field
// Based On: RadioField -> ValueField -> Field -> ViewElement
(function (RadioField, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    RadioField.Render = function (radioField) {

        // 508 Compliance
        var className = '';
        if (Common.IsNotDefined(radioField.Label)) {
            var generatedLabel = {
                TextString: radioField.Name,
                ScreenReaderOnly: true
            };
            if (Common.IsDefined(radioField.Placeholder)) {
                generatedLabel.TextString = radioField.Placeholder;
            }
            radioField.Label = generatedLabel;
        }

        // 508 Compliance
        if (radioField.Label.ScreenReaderOnly == true) {
            className += ' gtc-sr-only';
        }

        // Label
        var radioFieldMarkup = '<fieldset role="radiogroup" class="gtc-input-radio-group"><legend class="gtc-input-radio-label gtc-label' + className + '" for="' + radioField.Name + '"><span';

        // Translations
        if (Common.IsDefined(radioField.Label) && Common.IsDefined(radioField.Label.TextString)) {
            radioFieldMarkup += ' data-translate="' + radioField.Label.TextString + '"';
        }

        // Span>, Label, Span</>
        radioFieldMarkup += '>' + Common.TranslateKey(radioField.Label.TextString) + '</span>';
        radioFieldMarkup += Field.RenderLabel(radioField, true) + '</legend>';

        // Data-Disabled@
        var fieldAttributesMarkup = Field.RenderAttributes(radioField);

        // Build Radio
        if (Common.IsDefined(radioField.OptionDetail.Options)) {
            var option, index = 0, length = radioField.OptionDetail.Options.length;
            for ( ; index < length; index++) {
                option = radioField.OptionDetail.Options[index];
                var convertedToken = Common.SanitizeToken(option.Value);

                // @Data-NameSpace, @Data-FieldType, Label<, For@, Display, Input<
                radioFieldMarkup += '<label role="radio" class="gtc-input-radio" for="' + radioField.Name + convertedToken + '">' + option.Display + '<input data-namespace="RadioField"';

                // 508 Compliance
                if (radioField.IsRequired == 'Yes') {
                    radioFieldMarkup += ' aria-required="true"';
                }

                // Data-Serializable@
                if (radioField.IsSerializable == 'Yes') {
                    radioFieldMarkup += ' data-serializable';
                    Events.On(document.body, 'change.fieldvaluechange.' + radioField.Name + convertedToken, '#' + radioField.Name + convertedToken,
                        function () {
                            Common.SetAttr(this, 'data-haschanged', 'Yes');
                        }
                    );
                }

                // Data-Disabled@
                radioFieldMarkup += fieldAttributesMarkup;

                // @Checked
                if (Common.SanitizeToken(radioField.Value) == convertedToken) {
                    radioFieldMarkup += ' checked="checked"';
                }

                // Data-ControllerPath/ActionName@, Wire OnChange!
                if (Common.IsDefined(radioField.OnChange)) {
                    radioFieldMarkup += Field.AttachOnChange(radioField, RadioField.OnChange, convertedToken);
                }

                // @TabIndex, @Class, @Id, @Name, @Type, @Value
                radioFieldMarkup += ' tabindex="' + radioField.FocusIndex + '" class="gtc-input-radio-option" id="' + radioField.Name + convertedToken + '" name="' + radioField.Name + '" type="radio" value="' + option.Value + '" />';

                // Label</>
                radioFieldMarkup += '</label>';
            }
        }

        radioFieldMarkup += '</fieldset>';

        // Return
        return radioFieldMarkup;

    };

    RadioField.OnChange = function (event) {

        // Field Value
        var fieldValueUiParameter = [
            {
                Name: this.name,
                Value:  this.value,
                UiParameters: null
            }
        ];

        // Call OnChange
        Field.OnChange(this, fieldValueUiParameter);

    };

    RadioField.HasValue = function (radioField) {

        if (Common.IsDefined(radioField.Value)) {
            return true;
        }
        return false;

    };

    RadioField.IsCompleted = function (field) {

        var radioName = field.name;
        var index = 0, radios = Common.GetByName(radioName), radioLength = radios.length, radioValue;
        for ( ; index < radioLength; index++) {
            if (radios[index].checked == true) {
                radioValue = radios[index].value;
                break;
            }
        }
        if (Common.IsDefined(radioValue)) {
            return true;
        }
        return false;

    };

    RadioField.UpdateValue = function (field, fieldValue) {

        if (Common.IsNotEmptyString(fieldValue)) {
            if (fieldValue.length > 0) {
                var radioField = FindRadioField(field, fieldValue);
                if (Common.IsDefined(radioField)) {
                    radioField.checked = true;
                    if (Common.IsDefined(Common.GetAttr(radioField, 'data-serializable'))) {
                        Common.SetAttr(radioField, 'data-haschanged', 'Yes');
                    }
                    Common.SetAttr(radioField, 'value', fieldValue);
                    GTC.TriggerEvent(radioField, 'widgetUpdateValue');
                }
            }
        }
        else {
            var radioName = field[0].name;
            var index = 0, radios = Common.GetByName(radioName), radioLength = radios.length, radioValue;
            for (; index < radioLength; index++) {
                GTC.TriggerEvent(radios[index], 'widgetClearValue');
            }
        }
        Events.Trigger(field, 'focusout');

    };

    RadioField.ShowPinwheel = function (field) {

        Field.ShowPinwheel(field, 'FadingCircle');

    };

    RadioField.HidePinwheel = function (field) {

        Field.HidePinwheel(field);

    };

    function FindRadioField (field, fieldValue) {

        // Sanity Check
        if (Common.IsNotDefined(field)) {
            return null;
        }

        // Find Radio Field
        var radioField = null;
        var currentRadio, index = 0, length = field.length;
        for ( ; index < length; index++) {
            currentRadio = field[index];
            if (Common.SanitizeToken(currentRadio.value) == Common.SanitizeToken(fieldValue)) {
                radioField = currentRadio;
                break;
            }
        }
        return radioField;

    };

} (window.RadioField = window.RadioField || {}, window, document, Common, Cache, Events, Velocity));

// Progress Step
// Based On: ProgressStep -> ViewElement
(function (ProgressStep, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    ProgressStep.Render = function (progressStep, stepIndex) {

        var status = 'gtc-progressstep-status-';
        if (Common.IsDefined(progressStep.Status)) {
            status += progressStep.Status.toLowerCase();
        }
        else {
            progressStep.Status = 'None';
            status += 'none';
        }

        // Div<, TabIndex@, Class@, Id@, Div>
        var progressStepMarkup = '<div data-currentstatus="' + progressStep.Status + '" class="gtc-progressstep ' + status + '" data-namespace="ProgressStep"' + ViewElement.RenderAttributes(progressStep) + ' data-step="' + stepIndex + '">';

        // Title
        progressStepMarkup += '<div class="gtc-progressstep-title">';
        if (Common.IsDefined(progressStep.Title)) {
            progressStepMarkup += '<span data-translate="' + progressStep.Title + '">' + Common.TranslateKey(progressStep.Title) + '</span>';
            progressStepMarkup += '<span><i class="gtc-icon-styles fa fa-check"></i></span>';
        }
        progressStepMarkup += '</div>';

        // Expandable Details
        progressStepMarkup += '<div aria-expanded="false" id="' + progressStep.Name + 'Expandable" class="gtc-progressstep-expandable">';
        if (Common.IsDefined(progressStep.DisplayItems)) {
            progressStepMarkup += '';

            // Find length of items
            var displayItemCount = progressStep.DisplayItems.length;

            // Ul<>
            progressStepMarkup += '<ul class="gtc-progressstep-row">';

            // Display Fields
            var displayItem, index = 0;
            for ( ; index < displayItemCount; index++) {
                displayItem = progressStep.DisplayItems[index];

                // Build Display Item
                var displayItemNamespace = window[displayItem.Type.toString()];
                progressStepMarkup += displayItemNamespace.Render(displayItem);

                // Append Line?
                if (displayItem.AppendLine == 'Yes' && displayItemCount != index + 1) {
                    progressStepMarkup += '</ul><ul class="gtc-progressstep-row">';
                }
            }

            // Ul</>
            progressStepMarkup += '</ul>';

            // Wire click
            Events.On(document.body, 'click.' + progressStep.Name, '#' + progressStep.Name,
                function (event) {
                    event.preventDefault();
                    var currentStep = Common.Query('.gtc-progressstep-expandable', this);
                    var allExpandables = Common.QueryAll('.gtc-progressstep-expandable:not(#' + currentStep.id + ')'), index = 0, length = allExpandables.length;
                    for ( ; index < length; index++) {
                        Common.RemoveClass(allExpandables[index], 'gtc-progressstep-expandable-open');
                        Common.SetAttr(allExpandables[index], 'aria-expanded', 'false');
                    }
                    Velocity(allExpandables, 'slideUp');
                    if (Common.IsHidden(currentStep)) {
                        Velocity(currentStep, 'slideDown', 'slow',
                            function () {
                                Common.ResizeView();
                            }
                        );
                        Common.AddClass(this, 'gtc-progressstep-expandable-open');
                        Common.SetAttr(currentStep, 'aria-expanded', 'true');
                    }
                    else {
                        Velocity(currentStep, 'slideUp', 'slow',
                            function () {
                                Common.ResizeView();
                            }
                        );
                        Common.RemoveClass(this, 'gtc-progressstep-expandable-open');
                        Common.SetAttr(currentStep, 'aria-expanded', 'false');
                    }
                }
            );
        }
        progressStepMarkup += '</div>';

        // Div</>
        progressStepMarkup += '</div>';
        return progressStepMarkup;

    };

} (window.ProgressStep = window.ProgressStep || {}, window, document, Common, Cache, Events, Velocity));

// ProgressBar
// Based On: ProgressBar -> ViewElement
(function (ProgressBar, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    ProgressBar.Render = function (progressBar) {

        // Div<, TabIndex@, Class@, Id@, Div>
        var className = 'gtc-progressbar';
        if (progressBar.IsRounded == 'Yes') {
            className += ' gtc-progressbar-rounded';
        }
        var progressBarMarkup = '<div role="progressbar" aria-valuenow="0" class="' + className + '" data-namespace="ProgressBar"' + ViewElement.RenderAttributes(progressBar);

        // On Complete Event
        if (Common.IsDefined(progressBar.OnComplete)) {
            // Data-ControllerPath/ActionName
            progressBarMarkup += ' data-complete=\'' + JSON.stringify(progressBar.OnComplete) + '\'';
        }

        // Build Widget Options
        var options = {};

        // Color
        if (Common.IsDefined(progressBar.Color)) {
            options.Color = progressBar.Color;
        }

        // Add Striping?
        if (progressBar.HasStriping == 'Yes') {
            options.HasStriping = true;
        }
        else {
            options.HasStriping = false;
        }

        // Dimensions
        if (Common.IsDefined(progressBar.Dimension)) {
            if (Common.IsDefined(progressBar.Dimension.Height)) {
                options.Height = progressBar.Dimension.Height + progressBar.Dimension.Scale;
            }
            if (Common.IsDefined(progressBar.Dimension.Width)) {
                options.Width = progressBar.Dimension.Width + progressBar.Dimension.Scale;
            }
        }

        // On Complete
        if (Common.IsDefined(progressBar.OnComplete)) {
            options.OnCompleteEvent = true;
        }

        // Timed Fill?
        if (Common.IsDefined(progressBar.FillTime)) {
            options.FillTime = progressBar.FillTime;
        }

        // Hide On Complete?
        if (progressBar.HideOnComplete == 'Yes') {
            options.HideOnComplete = true;
        }
        else {
            options.HideOnComplete = false;
        }

        // Added option for page inserts (WaitToStart)
        if (progressBar.WaitsForFillInstructions == 'Yes') {
            options.WaitForStart = true;
        }
        else {
            options.WaitForStart = false;
        }

        // Configure progress bar on ready
        Events.One(document.body, 'configureprogressbar',
            function () {
                Widgets.progressbar(Common.Get(progressBar.Name), options);
            }
        );

        // Div</>
        progressBarMarkup += '></div>';
        return progressBarMarkup;

    };

    ProgressBar.OnComplete = function (progressBar) {

        // Initialize
        var onCompleteParameters = [];

        // Get OnCompleteEvent object
        var onCompleteEvent = JSON.parse(Common.GetAttr(progressBar, 'data-complete'));
        if (Common.IsDefined(onCompleteEvent.UiParameters)) {
            onCompleteParameters = onCompleteParameters.concat(onCompleteEvent.UiParameters);
        }

        // Execute View Behavior
        Common.ExecuteViewBehavior(onCompleteEvent.ControllerPath + onCompleteEvent.ActionName, onCompleteParameters, Page.RunInstructions, progressBar);

    };

    ProgressBar.UpdateValue = function (progressBar, uiParameter) {

        Events.Trigger(progressBar, 'widgetUpdateProgressBar' + progressBar.id, { FillToPercentage: uiParameter.Value });

    };

    ProgressBar.AppendContent = function (progressBar, viewElements, promises) {

        // Build Markup
        var progressBarMarkup = '';
        if (Common.IsDefined(viewElements) && viewElements.length == 1) {
            var progressBar = viewElements[0];
            progressBar.IsDisplayed = 'No';
            progressBar.WaitsForFillInstructions = true;
            progressBarMarkup += ProgressBar.Render(progressBar);

            // Get deferred object for animation
            var animationPromise = Common.Promise();
            promises.push(animationPromise.promise);

            // Append
            Common.InsertHTMLString(progressBar, Common.InsertType.Append, progressBarMarkup);
            Events.Trigger(document.body, 'configureprogressbar');
            Velocity(Common.Get(progressBar.Name), 'slideDown', 'slow',
                function () {
                    Widgets.progressbar(this, 'StartControl');
                    animationPromise.resolve();
                }
            );
        }

    };

} (window.ProgressBar = window.ProgressBar || {}, window, document, Common, Cache, Events, Velocity));

// PDFElement
// Based On: PDFElement -> ViewElement
(function (PDFElement, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    PDFElement.Render = function (pdfElement) {

        // Div<, Data-NameSpace@, TabIndex@, Class@, Id@, @Data-Height, Div>
        var pdfElementMarkup = '<div class="gtc-pdfelement" data-namespace="PDFElement"' + ViewElement.RenderAttributes(pdfElement);
        var embedElementMarkup = '<embed class="gtc-pdfelement-embed" type="application/pdf" src="data:application/pdf;base64,' + pdfElement.PDFData + '"';

        // Dimension styles
        if (Common.IsDefined(pdfElement.Dimension)) {
            // Height
            if (Common.IsDefined(pdfElement.Dimension.Height)) {
                pdfElementMarkup += ' data-height="' + pdfElement.Dimension.Height + pdfElement.Dimension.Scale + '"';
                embedElementMarkup += ' height="' + pdfElement.Dimension.Height + pdfElement.Dimension.Scale + '"';
            }

            // Width
            if (Common.IsDefined(pdfElement.Dimension.Width)) {
                pdfElementMarkup += ' data-width="' + pdfElement.Dimension.Width + pdfElement.Dimension.Scale + '"';
                embedElementMarkup += ' width="' + pdfElement.Dimension.Width + pdfElement.Dimension.Scale + '"';
            }
            else {
                embedElementMarkup += ' width="100%"';
            }
        }
        else {
            embedElementMarkup += ' width="100%"';
        }

        // Embed</>
        pdfElementMarkup += '>';
        embedElementMarkup += '></embed>';

        // Div</>
        pdfElementMarkup += embedElementMarkup + '</div>';
        return pdfElementMarkup;

    };

    PDFElement.UpdateValue = function (element, pdfData) {

        var embedElement = Common.Query('.gtc-pdfelement-embed', element);
        var embedElementMarkup = '<embed width="' + Common.GetAttr(element, 'data-width') + '" height="' + Common.GetAttr(element, 'data-height') + '" type="application/pdf" src="data:application/pdf;base64,' + pdfData + '"></embed>';
        Common.InsertHTMLString(embedElement, Common.InsertType.After, embedElementMarkup);
        Common.Remove(embedElement);

    };

} (window.PDFElement = window.PDFElement || {}, window, document, Common, Cache, Events, Velocity));

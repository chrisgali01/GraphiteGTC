// DisplayArea
// Based On: DisplayArea -> ContainerElement -> ViewElement
(function (DisplayArea, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    DisplayArea.Render = function (displayArea) {

        // Div<, NameSpace@
        var displayAreaMarkup = '<div data-namespace="DisplayArea"';

        // Styling class?
        var className = '';
        var styleClassName = '';
        displayArea = checkForStyles(displayArea);
        if (displayArea.HasStyles == true) {
            className += ' gtc-displayarea-' + displayArea.Name;
            styleClassName = 'gtc-displayarea-' + displayArea.Name;
        }

        // Disable Gridding?
        var disableGridding = false;
        className += ' gtc-displayarea-';
        if (displayArea.DisableAutoGrid == 'Yes') {
            disableGridding = true;
            className += 'nogrid';
        }
        else {
            className += 'grid';
        }

        // Class@, Id@
        displayAreaMarkup += ' class="gtc-displayarea ' + className + '"' + ViewElement.RenderAttributes(displayArea) + '>';

        // Styles
        if (displayArea.HasStyles == true) {
            displayAreaMarkup += '<style>';
            displayAreaMarkup += '.' + styleClassName + ' { ';
            if (Common.IsDefined(displayArea.DisplayType)) {
                displayAreaMarkup += 'display: ' + displayArea.DisplayType + ';';
            }
            if (Common.IsDefined(displayArea.VerticalAlignment)) {
                displayAreaMarkup += 'vertical-align: ' + displayArea.VerticalAlignment + ';';
            }
            displayAreaMarkup += 'opacity: ' + displayArea.Opacity + ';';
            if (Common.IsDefined(displayArea.Background) && (Common.IsOneDefined([displayArea.Background.Color, displayArea.Background.ImageSource]))) {
                if (Colors.IsGradient(displayArea.Background.Color) === true) {
                    var gradientValues = Colors.ProcessValue(displayArea.Background.Color, false, null);
                    displayAreaMarkup += 'background-image: -moz-linear-gradient(' + gradientValues[0] + ', ' + gradientValues[1] + ');';
                    displayAreaMarkup += 'background-image: -ms-linear-gradient(' + gradientValues[0] + ', ' + gradientValues[1] + ');';
                    displayAreaMarkup += 'background-image: -o-linear-gradient(' + gradientValues[0] + ', ' + gradientValues[1] + ');';
                    displayAreaMarkup += 'background-image: -webkit-gradient(linear, left top, left bottom, from(' + gradientValues[0] + '), to(' + gradientValues[1] + '));';
                    displayAreaMarkup += 'background-image: -webkit-linear-gradient(' + gradientValues[0] + ', ' + gradientValues[1] + ');';
                    displayAreaMarkup += 'background-image: linear-gradient(' + gradientValues[0] + ', ' + gradientValues[1] + ');';
                    displayAreaMarkup += 'filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=\'' + gradientValues[0] + '\', endColorstr=\'' + gradientValues[1] + '\')';
                    displayAreaMarkup += ';';
                }
                else {
                    (Common.IsDefined(displayArea.Background.Color) ? displayAreaMarkup += 'background-color:' + Colors.ProcessValue(displayArea.Background.Color, false, null) + ';' : displayAreaMarkup += '');
                    (Common.IsDefined(displayArea.Background.ImageSource) ? displayAreaMarkup += 'background:url(\'' + Common.BuildResourcePath(displayArea.Background.ImageSource) + '\');' : displayAreaMarkup += '');
                    (Common.IsDefined(displayArea.Background.Repeat) ? displayAreaMarkup += 'background-repeat:' + displayArea.Background.Repeat + ';' : displayAreaMarkup += '');
                    (Common.IsDefined(displayArea.Background.ImageSize) ? displayAreaMarkup += 'background-size:' + displayArea.Background.ImageSize + ';' : displayAreaMarkup += '');
                    if (Common.IsDefined(displayArea.Background.Position) && Common.IsOneDefined([displayArea.Background.Position.Top, displayArea.Background.Position.Left])) {
                        displayAreaMarkup += 'background-position:';
                        if (Common.IsDefined(displayArea.Background.Position.Left)) {
                            displayAreaMarkup += displayArea.Background.Position.Left;
                            if (isNaN(displayArea.Background.Position.Left) === false) {
                                displayAreaMarkup += displayArea.Background.Position.Scale;
                            }
                        }
                        else {
                            displayAreaMarkup += ' initial';
                        }
                        displayAreaMarkup += ' ';
                        if (Common.IsDefined(displayArea.Background.Position.Top)) {
                            displayAreaMarkup += displayArea.Background.Position.Top;
                            if (isNaN(displayArea.Background.Position.Top) === false) {
                                displayAreaMarkup += displayArea.Background.Position.Scale;
                            }
                        }
                        else {
                            displayAreaMarkup += 'initial';
                        }
                        displayAreaMarkup += ';';
                    }
                }
            }
            if (Common.IsDefined(displayArea.Border)) {
                (Common.IsDefined(displayArea.Border.Thickness) ? displayAreaMarkup += 'border-width:' + displayArea.Border.Thickness + displayArea.Border.Scale + ';' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.Border.BorderType) ? displayAreaMarkup += 'border-style:' + displayArea.Border.BorderType + ';' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.Border.Color) ? displayAreaMarkup += 'border-color:' + Colors.ProcessValue(displayArea.Border.Color, false, null) + ';' : displayAreaMarkup += '');
            }
            if (Common.IsDefined(displayArea.Dimension)) {
                if (Common.IsDefined(displayArea.Dimension.Height)) {
                    displayAreaMarkup += 'height: ' + displayArea.Dimension.Height + displayArea.Dimension.Scale + ';';
                }
                if (Common.IsDefined(displayArea.Dimension.Width)) {
                    displayAreaMarkup += 'width: ' + displayArea.Dimension.Width + displayArea.Dimension.Scale + ';';
                }
            }
            if (displayArea.IsContentCentered == 'Yes') {
                displayAreaMarkup += 'text-align: center;';
                displayAreaMarkup += '-webkit-justify-content: center;';
                displayAreaMarkup += '-ms-flex-pack: center;';
                displayAreaMarkup += 'justify-content: center;';
            }
            if (Common.IsDefined(displayArea.Margin)) {
                if (Common.IsDefined(displayArea.Margin.Top)) {
                    displayAreaMarkup += 'margin-top:';
                    if (displayArea.Margin.Top.toLowerCase() == 'auto') {
                        displayAreaMarkup += 'auto';
                    }
                    else {
                        displayAreaMarkup += displayArea.Margin.Top + displayArea.Margin.Scale;
                    }
                    displayAreaMarkup += ';';
                }
                if (Common.IsDefined(displayArea.Margin.Right)) {
                    displayAreaMarkup += 'margin-right:';
                    if (displayArea.Margin.Right.toLowerCase() == 'auto') {
                        displayAreaMarkup += 'auto';
                    }
                    else {
                        displayAreaMarkup += displayArea.Margin.Right + displayArea.Margin.Scale;
                    }
                    displayAreaMarkup += ';';
                }
                if (Common.IsDefined(displayArea.Margin.Bottom)) {
                    displayAreaMarkup += 'margin-bottom:';
                    if (displayArea.Margin.Bottom.toLowerCase() == 'auto') {
                        displayAreaMarkup += 'auto';
                    }
                    else {
                        displayAreaMarkup += displayArea.Margin.Bottom + displayArea.Margin.Scale;
                    }
                    displayAreaMarkup += ';';
                }
                if (Common.IsDefined(displayArea.Margin.Left)) {
                    displayAreaMarkup += 'margin-left:';
                    if (displayArea.Margin.Left.toLowerCase() == 'auto') {
                        displayAreaMarkup += 'auto';
                    }
                    else {
                        displayAreaMarkup += displayArea.Margin.Left + displayArea.Margin.Scale;
                    }
                    displayAreaMarkup += ';';
                }
            }
            if (Common.IsDefined(displayArea.Padding)) {
                if (Common.IsDefined(displayArea.Padding.Top)) {
                    displayAreaMarkup += 'padding-top:' + displayArea.Padding.Top + displayArea.Padding.Scale + ';';
                }
                if (Common.IsDefined(displayArea.Padding.Right)) {
                    displayAreaMarkup += 'padding-right:' + displayArea.Padding.Right + displayArea.Padding.Scale + ';';
                }
                if (Common.IsDefined(displayArea.Padding.Bottom)) {
                    displayAreaMarkup += 'padding-bottom:' + displayArea.Padding.Bottom + displayArea.Padding.Scale + ';';
                }
                if (Common.IsDefined(displayArea.Padding.Left)) {
                    displayAreaMarkup += 'padding-left:' + displayArea.Padding.Left + displayArea.Padding.Scale + ';';
                }
            }
            if (Common.IsDefined(displayArea.RoundedCorner)) {
                (Common.IsDefined(displayArea.RoundedCorner.TopLeft) ? displayAreaMarkup += 'border-top-left-radius:' + displayArea.RoundedCorner.TopLeft + 'px;' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.RoundedCorner.TopRight) ? displayAreaMarkup += 'border-top-right-radius:' + displayArea.RoundedCorner.TopRight + 'px;' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.RoundedCorner.BottomRight) ? displayAreaMarkup += 'border-bottom-right-radius:' + displayArea.RoundedCorner.BottomRight + 'px;' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.RoundedCorner.BottomLeft) ? displayAreaMarkup += 'border-bottom-left-radius:' + displayArea.RoundedCorner.BottomLeft + 'px;' : displayAreaMarkup += '');
            }
            if (Common.IsDefined(displayArea.Shadow)) {
                displayAreaMarkup += 'box-shadow: ';
                (Common.IsDefined(displayArea.Shadow.Horizontal) ? displayAreaMarkup += displayArea.Shadow.Horizontal + 'px ' : displayAreaMarkup += '0 ');
                (Common.IsDefined(displayArea.Shadow.ShadowType) && displayArea.Shadow.ShadowType != 'outset' ? displayAreaMarkup += displayArea.Shadow.ShadowType + ' ' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.Shadow.Vertical) ? displayAreaMarkup += displayArea.Shadow.Vertical + 'px ' : displayAreaMarkup += '0 ');
                (Common.IsDefined(displayArea.Shadow.Blur) ? displayAreaMarkup += displayArea.Shadow.Blur + 'px ' : displayAreaMarkup += '0 ');
                (Common.IsDefined(displayArea.Shadow.Spread) ? displayAreaMarkup += displayArea.Shadow.Spread + 'px ' : displayAreaMarkup += '0 ');
                (Common.IsDefined(displayArea.Shadow.Color) ? displayAreaMarkup += Colors.ProcessValue(displayArea.Shadow.Color, true, displayArea.Shadow.Opacity) : displayAreaMarkup += 'rgba(0,0,0,.6)');
                displayAreaMarkup += ';';
            }
            if (Common.IsDefined(displayArea.Position)) {
                (Common.IsDefined(displayArea.Position.Setting) ? displayAreaMarkup += 'position: ' + displayArea.Position.Setting + ';' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.Position.Top) ? displayAreaMarkup += 'top: ' + displayArea.Position.Top + displayArea.Position.Scale + ';' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.Position.Right) ? displayAreaMarkup += 'right: ' + displayArea.Position.Right + displayArea.Position.Scale + ';' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.Position.Bottom) ? displayAreaMarkup += 'bottom: ' + displayArea.Position.Bottom + displayArea.Position.Scale + ';' : displayAreaMarkup += '');
                (Common.IsDefined(displayArea.Position.Left) ? displayAreaMarkup += 'left: ' + displayArea.Position.Left + displayArea.Position.Scale + ';' : displayAreaMarkup += '');
            }
            if (Common.IsDefined(displayArea.Font)) {
                if (Common.IsDefined(displayArea.Font.Color)) {
                    displayAreaMarkup += 'color: ' + Colors.ProcessValue(displayArea.Font.Color, false, null) + ';';
                }
                if (Common.IsDefined(displayArea.Font.Size)) {
                    displayAreaMarkup += 'font-size: ' + displayArea.Font.Size + displayArea.Font.Scale + ';';
                }
                if (Common.IsDefined(displayArea.Font.Weight)) {
                    displayAreaMarkup += 'font-weight: ' + displayArea.Font.Weight.toLowerCase() + ';';
                }
                if (Common.IsDefined(displayArea.Font.LineSpacing)) {
                    displayAreaMarkup += 'line-height: ' + displayArea.Font.LineSpacing + 'px;';
                }
                if (Common.IsDefined(displayArea.Font.LetterSpacing)) {
                    displayAreaMarkup += 'letter-spacing: ' + displayArea.Font.LetterSpacing + 'px;';
                }
            }
            if (Common.IsDefined(displayArea.Layer)) {
                displayAreaMarkup += 'z-index: ' + displayArea.Layer + ';';
            }
            displayAreaMarkup += ' }';
            displayAreaMarkup += '</style>';
        }

        // DisplayArea
        displayAreaMarkup += ContainerElement.RenderElements(displayArea, disableGridding, false, true);

        // Div</>
        displayAreaMarkup += '</div>';
        return displayAreaMarkup;

    };

    // Private Methods
    function checkForStyles (displayArea) {

        displayArea.HasStyles = false;
        if (Common.IsDefined(displayArea.Name)) {
            if (Common.IsDefined(displayArea.DisplayType)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.VerticalAlignment)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Background) && Common.IsOneDefined([displayArea.Background.Color, displayArea.Background.ImageSource])) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Border)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Dimension) && Common.IsOneDefined([displayArea.Dimension.Height, displayArea.Dimension.Width])) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (displayArea.IsContentCentered == 'Yes') {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Margin)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Padding)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.RoundedCorner)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Shadow)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Position)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Font) && Common.IsOneDefined([displayArea.Font.Color, displayArea.Font.Size, displayArea.Font.Weight])) {
                displayArea.HasStyles = true;
                return displayArea;
            }
            if (Common.IsDefined(displayArea.Layer)) {
                displayArea.HasStyles = true;
                return displayArea;
            }
        }
        return displayArea;

    };


} (window.DisplayArea = window.DisplayArea || {}, window, document, Common, Cache, Events, Velocity));

// Numeric Field
// Based On: NumericField -> MaskField -> PlaceholderField -> ValueField -> Field -> ViewElement
(function (NumericField, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    NumericField.Render = function (numericField) {

        // Label
        var numericFieldMarkup = Field.RenderLabel(numericField);

        // input<, Data-Mask@, Placeholder@, Name@, Value@, @Data-Serializable, TabIndex@, Class@, Id@, Data-Disabled@
        numericFieldMarkup += '<input class="gtc-input-calculator"' + MaskField.RenderAttributes(numericField) + Field.RenderAttributes(numericField);

        // Data-HasChanged@ Event
        if (numericField.IsSerializable == 'Yes') {
            Events.On(document.body, 'change.fieldvaluechange.' + numericField.Name, '#' + numericField.Name,
                function () {
                    Common.SetAttr(this, 'data-haschanged', 'Yes');
                }
            );
        }

        // 508 Compliance
        if (numericField.IsRequired == 'Yes') {
            numericFieldMarkup += ' aria-required="true"';
        }

        // Data-ControllerPath/ActionName@, Wire OnChange!
        if (Common.IsDefined(numericField.OnChange)) {
            numericFieldMarkup += Field.AttachOnChange(numericField, NumericField.OnChange);
        }

        // @Data-NameSpace, @Data-FieldType, Type@, Input/>
        numericFieldMarkup += ' data-namespace="NumericField" type="text" />';
        return numericFieldMarkup;

    };

    NumericField.OnChange = function(event) {

        // Field Value
        var fieldValueUiParameter = [
            {
                Name: this.name,
                Value:  this.value,
                UiParameters: null
            }
        ];

        // Call OnChange
        Field.OnChange(this, fieldValueUiParameter);

    };

    NumericField.HasValue = function (numericField) {

        return MaskField.HasValue(numericField);

    };

    NumericField.IsCompleted = function (field) {

        return MaskField.IsCompleted(field);

    };

    NumericField.UpdateValue = function (field, fieldValue) {

        MaskField.UpdateValue(field, fieldValue);

    };

    NumericField.ShowPinwheel = function (field) {

        Field.ShowPinwheel(field, 'FadingCircle');

    };

    NumericField.HidePinwheel = function (field) {

        Field.HidePinwheel(field);

    };

} (window.NumericField = window.NumericField || {}, window, document, Common, Cache, Events, Velocity));

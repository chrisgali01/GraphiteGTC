// Icon
// Based On: Icon -> ViewElement
(function (Icon, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    Icon.Render = function (icon, isOnField) {

        var iconTextMarkup = '';
        if (Common.IsDefined(icon.Symbol)) {
            var iconType = icon.Symbol.split('-')[0];
            if (iconType == 'gtc') {
                iconType += '-icon';
            }
            iconTextMarkup += '<i class="';
            if (isOnField) {
                iconTextMarkup += 'gtc-input-custom ';
            }
            iconTextMarkup += 'gtc-icon-styles ' + iconType;
            iconTextMarkup += ' ' + icon.Symbol.toLowerCase() + '"';
            iconTextMarkup += '></i>';
        }
        return iconTextMarkup;

    };

} (window.Icon = window.Icon || {}, window, document, Common, Cache, Events, Velocity));

// Progress Poll
// Based On: ProgressPoll -> ViewElement
(function (ProgressPoll, window, document, Common, Cache, Events, Velocity, undefined) {

    // Public Methods
    ProgressPoll.Render = function (progressPoll) {

        // Div<, TabIndex@, Class@, Id@, Div>
        var progressPollMarkup = '<div class="gtc-progresspoll" data-currentstep="1" data-namespace="ProgressPoll"' + ViewElement.RenderAttributes(progressPoll);

        // Polling Interval
        if (Common.IsDefined(progressPoll.PollingInterval)) {
            progressPollMarkup += '  data-pollinginterval="' + progressPoll.PollingInterval + '"';
        }

        // Steps
        if (Common.IsDefined(progressPoll.NumberOfSteps)) {
            progressPollMarkup += '  data-numberofsteps="' + progressPoll.NumberOfSteps + '"';
        }

        // On Poll Event
        if (Common.IsDefined(progressPoll.OnPoll)) {
            // Data-ControllerPath/ActionName
            progressPollMarkup += ' data-poll=\'' + JSON.stringify(progressPoll.OnPoll) + '\'';
        }

        // On Complete Event
        if (Common.IsDefined(progressPoll.OnComplete)) {
            // Data-ControllerPath/ActionName
            progressPollMarkup += ' data-complete=\'' + JSON.stringify(progressPoll.OnComplete) + '\'';
        }
        progressPollMarkup += '>';

        // H2<>, Title, H2</>
        if (Common.IsDefined(progressPoll.Title)) {
            progressPollMarkup += '<h2 id="' + progressPoll.Name + 'Title" class="gtc-page-theme-color"';

            // Translations
            progressPollMarkup += ' data-translate="' + progressPoll.Title + '"';
            progressPollMarkup += '>' + Common.TranslateKey(progressPoll.Title) + '</h2>';
        }

        // P<>, Subtitle, P</>
        if (Common.IsDefined(progressPoll.Subtitle)) {
            progressPollMarkup += '<p';

            // Translations
            progressPollMarkup += ' data-translate="' + progressPoll.Subtitle + '"';
            progressPollMarkup += '>' + Common.TranslateKey(progressPoll.Subtitle) + '</p>';
        }

        // Steps
        progressPollMarkup += '<div class="gtc-progresspoll-steps">';
        if (Common.IsDefined(progressPoll.ProgressSteps)) {
            var index = 0, length = progressPoll.ProgressSteps.length;
            for ( ; index < length; index++) {
                progressPollMarkup += ProgressStep.Render(progressPoll.ProgressSteps[index], index + 1);
            }
        }
        progressPollMarkup += '</div>';

        // Configure polling on ready
        Events.One(document.body, 'configureprogresspoll',
            function () {
                var poll = Common.Get(progressPoll.Name);
                if (progressPoll.WaitForStartInstruction != 'Yes') {
                    var intervalId = setInterval(
                        function () {
                            ProgressPoll.OnPoll(poll);
                        }, parseInt(Common.GetAttr(poll, 'data-pollinginterval'), 10) * 1000
                    );
                    Common.SetAttr(poll, 'data-intervalid', intervalId);

                    // Start first if its pending
                    if (Common.GetAttr(Common.Query('.gtc-progressstep[data-step="1"]'), 'data-currentstatus') == 'Pending') {
                        ShowNextMessage(poll);
                    }
                }

                // Complete on progressbar
                if (Common.IsDefined(progressPoll.ProgressBar)) {
                    Events.One(document.body, 'progressbarcomplete',
                        function () {
                            ProgressPoll.OnComplete(poll);
                        }
                    );
                }
            }
        );

        if (Common.IsDefined(progressPoll.ProgressBar)) {
            if (progressPoll.WaitForStartInstruction == 'Yes') {
                progressPoll.ProgressBar.WaitForStart = 'Yes';
            }
            progressPollMarkup += ProgressBar.Render(progressPoll.ProgressBar);
        }

        // Div</>
        progressPollMarkup += '</div>';
        return progressPollMarkup;

    };

    ProgressPoll.UpdatePollingInterval = function (progressPoll, uiParameter) {

        clearInterval(Common.GetAttr(progressPoll, 'data-intervalid'));
        var intervalId = setInterval(
            function () {
                ProgressPoll.OnPoll(progressPoll);
            }, parseInt(uiParameter.Value, 10) * 1000
        );
        Common.SetAttr(progressPoll, 'data-intervalid', intervalId);

    };

    ProgressPoll.UpdatePollingStep = function (progressPoll, value) {

        if (value == 'Complete') {
            ShowComplete(progressPoll, true);
        }
        else if (value == 'Next') {
            ShowNextMessage(progressPoll);
        }

    };

    ProgressPoll.UpdateValue = function (progressPoll, value) {

        if (value == 'Start') {
            var intervalId = setInterval(
                function () {
                    ProgressPoll.OnPoll(progressPoll);
                }, parseInt(Common.GetAttr(progressPoll, 'data-pollinginterval'), 10) * 1000
            );
            Common.SetAttr(progressPoll, 'data-intervalid', intervalId);

            // Start ProgressBar
            var progressbar = Common.Query('.gtc-progressbar', progressPoll);
            if (Common.IsDefined(progressbar)) {
                Widgets.progressbar(progressbar, 'StartControl');
            }

            // Start first if its pending
            if (Common.GetAttr(Common.Query('.gtc-progressstep[data-step="1"]'), 'data-currentstatus') == 'Pending') {
                ShowNextMessage(progressPoll);
            }
        }

    };

    ProgressPoll.OnPoll = function (progressPoll) {

        // Initialize
        var onPollParameters = [];

        // Get OnPollEvent object
        var onPollData = Common.GetAttr(progressPoll, 'data-poll');
        if (Common.IsDefined(onPollData)) {
            var onPollEvent = JSON.parse(onPollData);
            if (Common.IsDefined(onPollEvent.UiParameters)) {
                onPollParameters = onPollParameters.concat(onPollEvent.UiParameters);
            }

            // Setup CurrentPollCount Ui Parameter
            var currentPollCount = Common.GetAttr(progressPoll, 'data-currentpollcount');
            if (Common.IsDefined(currentPollCount)) {
                currentPollCount = parseInt(currentPollCount, 10);
                currentPollCount++;
            }
            else {
                currentPollCount = 1;
            }
            Common.SetAttr(progressPoll, 'data-currentpollcount', currentPollCount);
            var currentPollParameter = [
                {
                    Name: 'CurrentPollCount',
                    Value: currentPollCount,
                    UiParameters: null
                }
            ];

            // Add CurrentPollCount
            onPollParameters = onPollParameters.concat(currentPollParameter);

            // Execute View Behavior
            Common.ExecuteViewBehavior(onPollEvent.ControllerPath + onPollEvent.ActionName, onPollParameters, Page.RunInstructions, progressPoll);
        }

    };

    ProgressPoll.OnComplete = function (progressPoll) {

        // Initialize
        var onCompleteParameters = [];

        // Stop Polling
        clearInterval(Common.GetAttr(progressPoll, 'data-intervalid'));

        // Get OnCompleteEvent object
        var onCompleteData = Common.GetAttr(progressPoll, 'data-complete');
        if (Common.IsDefined(onCompleteData)) {
            var onCompleteEvent = JSON.parse(onCompleteData);
            if (Common.IsDefined(onCompleteEvent.UiParameters)) {
                onCompleteParameters = onCompleteParameters.concat(onCompleteEvent.UiParameters);
            }

            // Execute View Behavior
            Common.ExecuteViewBehavior(onCompleteEvent.ControllerPath + onCompleteEvent.ActionName, onCompleteParameters, Page.RunInstructions, progressPoll);
        }

    };

    ProgressPoll.UpdateTitle = function (progressPoll, updatedTitle, promises, context) {

        // Initialize
        var onParent = context == 'Parent';
        var title = Common.Get(progressPoll.id + 'Title', onParent);
        var updateTitleFunction = function () {
            title.textContent = Common.TranslateKey(updatedTitle);
            Common.SetAttr(title, 'data-translate', updatedTitle);
        };
        if (Common.IsHidden(progressPoll)) {
            updateTitleFunction();
        }
        else {
            // Get deferred object for animation
            var animationPromise = Common.Promise();
            promises.push(animationPromise.promise);

            // Animate
            Velocity(title, { 'opacity': 0 }, 'slow',
                function () {
                    updateTitleFunction();
                    Velocity(title, 'reverse',
                        function () {
                            Common.RemoveOpacity(title);
                            animationPromise.resolve();
                        }
                    );
                }
            );
        }

    };

    // Private Methods
    function ShowNextMessage (progressPoll) {

        var currentStep = parseInt(Common.GetAttr(progressPoll, 'data-currentstep'), 10);
        var numberOfSteps = parseInt(Common.GetAttr(progressPoll, 'data-numberofsteps'), 10);
        if (currentStep < numberOfSteps) {
            var currentStep = Common.Query('.gtc-progressstep[data-step="' + currentStep + '"]', progressPoll);
            var currentStatus = Common.GetAttr(currentStep, 'data-currentstatus');
            Events.One(currentStep, 'transitionend',
                function () {
                    Common.AddClass(currentStep, 'gtc-progressstep-status-complete');
                }
            );
            Common.RemoveClass(currentStep, 'gtc-progressstep-status-' + currentStatus.toLowerCase());
            Velocity(Common.Query('.gtc-progressstep-title > span:last-child', currentStep), 'fadeIn', 'slow');
            var nextStep = currentStep + 1;
            if (nextStep < numberOfSteps) {
                var nextStep = Common.Query('.gtc-progressstep[data-step="' + nextStep + '"]', progressPoll);
                if (Common.IsDefined(nextStep)) {
                    currentStatus = Common.GetAttr(nextStep, 'data-currentstatus');
                    Events.One(nextStep, 'transitionend',
                        function () {
                            Common.AddClass(nextStep, 'gtc-progressstep-status-running');
                        }
                    );
                    Common.RemoveClass(nextStep, 'gtc-progressstep-status-' + currentStatus.toLowerCase());
                    Velocity(Common.Query('.gtc-progressstep-title > span:last-child', nextStep), 'fadeIn', 'slow');
                }
            }
        }
        else {
            ShowComplete(progressPoll, true);
        }

    };

    function ShowComplete (progressPoll, completeProgressBar) {

        var allSteps = Common.QueryAll('.gtc-progressstep', progressPoll);
        var step, index = 0, length = allSteps.length;
        for ( ; index < length; index++) {
            step = allSteps[index];
            var currentStatus = Common.GetAttr(step, 'data-currentstatus');

            // For loops have no scope! Give it some. (IIFE)
            (function (step, currentStatus) {

                Events.One(step, 'transitionend',
                    function () {
                        Common.AddClass(step, 'gtc-progressstep-status-complete');
                    }
                );
                Common.RemoveClass(step, 'gtc-progressstep-status-' + currentStatus.toLowerCase());

            }(step, currentStatus));

            // Fade in
            Velocity(Common.Query('.gtc-progressstep-title > span:last-child', step), 'fadeIn', 'slow');
        }

        // Complete ProgressBar
        var progressbar = Common.Query('.gtc-progressbar', progressPoll);
        if (Common.IsDefined(progressbar) && completeProgressBar) {
            Widgets.progressbar(progressbar, 'CompleteAnimation');
        }
        else {
            ProgressPoll.OnComplete(progressPoll);
        }

    };

} (window.ProgressPoll = window.ProgressPoll || {}, window, document, Common, Cache, Events, Velocity));

/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","km",{
	"alt":"អត្ថបទជំនួស",
	"lockRatio":"អត្រាឡុក",
	"vSpace":"VSpace",
	"hSpace":"គំលាតទទឹង",
	"border":"ស៊ុម"
});